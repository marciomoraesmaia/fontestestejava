package br.com.avaliacaoekan.avaliacao.ekan.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.avaliacaoekan.avaliacao.ekan.entities.Documento;

public interface DocumentoRepository extends JpaRepository<Documento, Long>{

}
