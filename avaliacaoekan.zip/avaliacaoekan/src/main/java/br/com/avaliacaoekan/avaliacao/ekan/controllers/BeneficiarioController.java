package br.com.avaliacaoekan.avaliacao.ekan.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.avaliacaoekan.avaliacao.ekan.entities.Beneficiario;
import br.com.avaliacaoekan.avaliacao.ekan.repositories.BeneficiarioRepository;

@RestController

public class BeneficiarioController {
	@Autowired
	private BeneficiarioRepository beneficiariorepository;
	
	@GetMapping("/api/beneficiarios/get/{id}")
	public Beneficiario getBeneficiarios(@PathVariable Long id) {
		return beneficiariorepository.findById(id).get();
	}
	@DeleteMapping("/api/beneficiarios/delete/{id}")
	public BodyBuilder deleteBeneficiarios(@PathVariable Long id) {
	 beneficiariorepository.deleteById(id);
	 return ResponseEntity.ok();
	}
	@GetMapping("/api/beneficiarios/lista")
	public List<Beneficiario> listaBeneficiarios() {
		return beneficiariorepository.findAll();
	}
	
	@PostMapping("/api/beneficiarios")
	public Beneficiario insert(@RequestBody @Validated Beneficiario beneficiario) {
		beneficiario.setPassword(new BCryptPasswordEncoder().encode(beneficiario.getPassword()));
		return beneficiariorepository.save(beneficiario);
	}	
	
	@Transactional
	@PutMapping("/api/beneficiarios/update/{id}")
	public Beneficiario update(@RequestBody @Validated Beneficiario beneficiario, @PathVariable Long id ) throws Exception {
		
	
			Optional<Beneficiario> result = beneficiariorepository.findById(id);
			if(result.isPresent()) {
				Beneficiario beneficiariofinal = result.get();
				if(!beneficiario.getNome().equals("")|| !(beneficiario.getNome() == null) ) 						beneficiariofinal.setNome(beneficiario.getNome());
				if(!beneficiario.getTelefone().equals("")|| !(beneficiario.getTelefone() == null) ) 				beneficiariofinal.setTelefone(beneficiario.getTelefone());
				if(!beneficiario.getDatanascimento().equals("")|| !(beneficiario.getDatanascimento() == null) ) 	beneficiariofinal.setDatanascimento(beneficiario.getDatanascimento());
				if(!beneficiario.getDataatualizacao().equals("")|| !(beneficiario.getDataatualizacao() == null) ) 	beneficiariofinal.setDataatualizacao(beneficiario.getDataatualizacao());
				return beneficiariofinal;
			}
			
			throw new Exception("Beneficiario não encontrado!");
		
	}	
	
}
