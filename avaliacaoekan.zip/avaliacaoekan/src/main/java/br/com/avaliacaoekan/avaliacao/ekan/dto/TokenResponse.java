package br.com.avaliacaoekan.avaliacao.ekan.dto;

import java.util.Date;

public class TokenResponse {
	
	private String type;

	private String token;

	private Date dateExpiration;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Date getDateExpiration() {
		return dateExpiration;
	}

	public void setDateExpiration(Date dateExpiration) {
		this.dateExpiration = dateExpiration;
	}

	public TokenResponse(String type, String token, Date dateExpiration) {
		super();
		this.type = type;
		this.token = token;
		this.dateExpiration = dateExpiration;
	}

}
