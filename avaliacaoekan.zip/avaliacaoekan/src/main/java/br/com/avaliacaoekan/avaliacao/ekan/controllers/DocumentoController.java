package br.com.avaliacaoekan.avaliacao.ekan.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.avaliacaoekan.avaliacao.ekan.entities.Beneficiario;
import br.com.avaliacaoekan.avaliacao.ekan.entities.Documento;
import br.com.avaliacaoekan.avaliacao.ekan.repositories.BeneficiarioRepository;
import br.com.avaliacaoekan.avaliacao.ekan.repositories.DocumentoRepository;

@RestController

public class DocumentoController {
	@Autowired
	private DocumentoRepository documentoRepository;
	
	@Autowired
	private BeneficiarioRepository  beneficiarioRepository; 
	
	@GetMapping("/api/documentos/get/{id}")
	public Documento getDocumentos(@PathVariable Long id) {
		return documentoRepository.findById(id).get();
	}
	@DeleteMapping("/api/documentos/delete/{id}")
	public BodyBuilder deleteDocumentos(@PathVariable Long id) {
		documentoRepository.deleteById(id);
	 return ResponseEntity.ok();
	}
	@GetMapping("/api/documentos/lista")
	public List<Documento> listaDocumentos() {
		return documentoRepository.findAll();
	}
	
	@PostMapping("/api/documentos")
	public Documento insert(@RequestBody @Validated Documento documento) throws Exception {
	System.out.println("ID DO USUARIO: "+documento.getBeneficiario().getId());
	Optional<Beneficiario> optionalBeneficiario = 	beneficiarioRepository.findById(documento.getBeneficiario().getId());
	    if(optionalBeneficiario.isPresent()) {
	    	Beneficiario beneficiario = optionalBeneficiario.get();
	    	documento.setBeneficiario(beneficiario);
	    	return documentoRepository.save(documento);
	    	
	    }
	    throw new Exception("beneficiario não encontrado!");
	}	
	
	@Transactional
	@PutMapping("/api/documentos/update/{id}")
	public Documento update(@RequestBody @Validated Documento documento, @PathVariable Long id ) throws Exception {
		
			Optional<Documento> result = documentoRepository.findById(id);
			if(result.isPresent()) {
				Documento documentofinal = result.get();
				
				if(!documento.getDescricao().equals("")|| !(documento.getDescricao() == null) ) 			documentofinal.setDescricao(documento.getDescricao());
				if(!documento.getDataatualizacao().equals("")|| !(documento.getDataatualizacao() == null) ) documentofinal.setDataatualizacao(documento.getDataatualizacao());
				
				
				return documentofinal;
				
			}
			
			throw new Exception("Documento não encontrado!");
		
	}	
}
