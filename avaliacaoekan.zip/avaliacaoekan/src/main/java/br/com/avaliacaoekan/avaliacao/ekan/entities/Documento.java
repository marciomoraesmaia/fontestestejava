package br.com.avaliacaoekan.avaliacao.ekan.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "documento")
public class Documento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "documento_seq")
	@SequenceGenerator(name = "documento_seq", sequenceName = "documento_seq", allocationSize = 1)
	private Long id;
	
	private String tipodocumento;
	
	private String descricao;
	
	private Date datainclusao;
	
	private Date dataatualizacao;
	@ManyToOne
	@JoinColumn(name = "beneficiario_id")
	private Beneficiario beneficiario;

	public Beneficiario getBeneficiario() {
		return beneficiario;
	}

	public void setBeneficiario(Beneficiario beneficiario) {
		this.beneficiario = beneficiario;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTipodocumento() {
		return tipodocumento;
	}

	public void setTipodocumento(String tipodocumento) {
		this.tipodocumento = tipodocumento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Date getDatainclusao() {
		return datainclusao;
	}

	public void setDatainclusao(Date datainclusao) {
		this.datainclusao = datainclusao;
	}

	public Date getDataatualizacao() {
		return dataatualizacao;
	}

	public void setDataatualizacao(Date dataatualizacao) {
		this.dataatualizacao = dataatualizacao;
	}
}
