package br.com.avaliacaoekan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class AvaliacaoekanApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoekanApplication.class, args);
	}

	
}
