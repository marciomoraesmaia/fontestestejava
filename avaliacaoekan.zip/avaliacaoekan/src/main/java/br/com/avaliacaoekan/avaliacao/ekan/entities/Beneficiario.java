package br.com.avaliacaoekan.avaliacao.ekan.entities;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@javax.persistence.Entity
@Table(name = "beneficiario")
public class Beneficiario implements UserDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "beneficiario_seq")
	@SequenceGenerator(name = "beneficiario_seq", sequenceName = "beneficiario_seq", allocationSize = 1)
    private Long 			id;			
    private String 			nome; 	
    
    @OneToMany(mappedBy = "beneficiario")
    
    private List<Documento> documentos;
    
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public Date getDatanascimento() {
		return datanascimento;
	}
	public void setDatanascimento(Date datanascimento) {
		this.datanascimento = datanascimento;
	}
	public LocalDateTime getDatainclusao() {
		return datainclusao;
	}
	public void setDatainclusao(LocalDateTime datainclusao) {
		this.datainclusao = datainclusao;
	}
	public LocalDateTime getDataatualizacao() {
		return dataatualizacao;
	}
	public void setDataatualizacao(LocalDateTime dataatualizacao) {
		this.dataatualizacao = dataatualizacao;
	}

	private String 			telefone; 	
    private Date 			datanascimento; 
    private LocalDateTime	datainclusao;
    private LocalDateTime	dataatualizacao;
    private String 			username;
    private String 			password;

	public void setUsername(String username) {
		this.username = username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}
	@Override
	public String getPassword() {
		return this.password;
	}
	@Override
	public String getUsername() {
		return this.username;
	}
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	@Override
	public boolean isEnabled() {
		return true;
	}
	
	public UsernamePasswordAuthenticationToken getAuth() {
		System.out.println("username: "+this.username);
		System.out.println("password: "+this.password);
		return new UsernamePasswordAuthenticationToken(this.username, this.password);
	}
	
}
