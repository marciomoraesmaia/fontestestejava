package br.com.avaliacaoekan.avaliacao.ekan.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.avaliacaoekan.avaliacao.ekan.entities.Beneficiario;
import br.com.avaliacaoekan.avaliacao.ekan.repositories.BeneficiarioRepository;

@Service
public class AuthService implements UserDetailsService {

	@Autowired
	private BeneficiarioRepository repository;
 

    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Beneficiario beneficiario = repository.findByUsername(username);
        if (beneficiario == null) {
            throw new UsernameNotFoundException("Usuário não encontrado");
        }
       
        
        return beneficiario;
    }
    
   
}