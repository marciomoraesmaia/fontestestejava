package br.com.avaliacaoekan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoekanApplicationTests {

	@Test
	void contextLoads() {
	}

}
